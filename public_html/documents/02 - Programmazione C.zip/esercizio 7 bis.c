/*Scrivere un programma che, dati tre numeri interi inseriti da tastiera,
li stampi a video disponendoli prima in modo crescente e poi decrescente.
*/
#include <stdio.h>

int main()
{
    int a, b, c, primo, secondo, terzo;
    printf("Inserisci il valore di A B C : \n");
    scanf("%d %d %d", &a, &b, &c);
    if (a >= b){
        if (a >= c)
        {
            primo = a;
            if (b >= c)
            {
                secondo = b;
                terzo = c;
            }
            else
            {
                secondo = c;
                terzo = b;
            }
        }else
        {
            primo = c;
            secondo = a;
            terzo = b;
        }
    }
    else
    {
        if (a >= c)
        {
            primo = b;
            secondo = a;
            terzo = c;
        }
        else
        {
            terzo = a;
        }
        if (b >= c)
        {
        primo = b;
        }
        else
        {
            primo = c;
            secondo = b;
            terzo = a;
        }
    }
    printf("Valori in ordine decrescente: %d %d %d\n", primo, secondo, terzo);
    printf("Valori in ordine crescente: %d %d %d\n", terzo, secondo, primo);
    return 0;
}
