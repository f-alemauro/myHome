/*Scrivere un programma che chieda in ingresso un anno e dica se è bisestile o no
[suggerimento: un anno è bisestile se è multiplo di 4 ma non di 100 oppure multiplo di 400]
*/

#include <stdio.h>

int main()
{
    int year;
    printf("Che anno vuoi verificare? ");
    scanf("%d",&year);

    if ((year%4 == 0 && year%100 != 0)||(year%400 == 0))
        printf("L'anno %d è bisestile\n",year);
    else
        printf("L'anno %d non è bisestile\n",year);
    return 0;
}
