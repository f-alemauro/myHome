/*Scrivere un programma che chieda all’utente di inserire dei numeri interi:
ogni numero pari viene addizionato alla somma dei precedenti mentre ogni numeri dispari
viene sottratto alla somma dei precedenti;
il programma si deve arrestare appena l’utente inserisce un numero pari maggiore di 100,
stampando la somma ottenuta fino a quel momento.
*/

#include <stdio.h>

int main()
{
    int sum=0, num;

    printf("Inserisci un numero: ");
    scanf("%d",&num);

    while(num<=100 || num%2!=0)
    {
        if (num%2==0)
            sum+=num;
        else
            sum-=num;
        printf("Inserisci un altro numero: ");
        scanf("%d",&num);
    }

    printf("La somma è %d",sum);

    return 0;
}
