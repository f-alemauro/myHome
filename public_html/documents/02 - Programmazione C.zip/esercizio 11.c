/*Scrivere un programma che chieda all’utente di inserire numeri interi
e li ristampi immediatamente a video fino quando l’utente inserisce un numero dispari
maggiore della somma di tutti i precedenti.
*/

#include <stdio.h>

int main()
{
    int num, sum = 0;

    printf("Inserici un numero: ");
    scanf("%d",&num);
    while (num <= sum || num%2==0)
    {
        sum += num;
        printf("Inserici un altro numero: ");
        scanf("%d",&num);

     }
     return 0;
}
