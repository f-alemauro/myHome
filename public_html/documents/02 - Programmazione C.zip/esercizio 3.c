/*Scrivere un programma che, dato un numero intero inserito da tastiera
e corrispondente al raggio di un cerchio, ne calcoli perimetro e circonferenza;
stampare a video i risultati
*/

#include <stdio.h>

int main()
{
    int radius;
    float area, perimeter;

    printf("Inserisci il raggio del cerchio in cm: ");
    scanf("%d",&radius);

    perimeter = 2*3.14f*radius;
    area = 3.14*radius*radius;

    printf("Il perimetro del cerchio è %.3f cm\n",perimeter);
    printf("L'area del cerchio è %.3f cm\n",area);

    return 0;


}
