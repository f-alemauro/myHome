/*Scrivere un programma che chieda all’utente di inserire numeri interi da tastiera e
li ristampi immediatamente a video; il programma termina quando l’utente inserisce uno zero
(lo zero non deve essere stampato a video).
*/

#include <stdio.h>

int main()
{
    int num;

    printf("Inserisci un numero: ");
    scanf("%d",&num);

    while(num!=0)
    {
        printf("Hai inserito %d.\n",num);
        printf("Inserisci il prossimo numero: ");
        scanf("%d",&num);

    }

    return 0;
}
