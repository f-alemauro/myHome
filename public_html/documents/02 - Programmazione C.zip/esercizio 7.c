/* Scrivere un programma che, dati tre numeri interi inseriti da tastiera,
li stampi a video disponendoli prima in modo crescente e poi decrescente.
*/

#include <stdio.h>

int main()
{
    int a,b,c;

    printf("Inserisci il primo numero: ");
    scanf("%d",&a);
    printf("Inserisci il secondo numero: ");
    scanf("%d",&b);
    printf("Inserisci il terzo numero: ");
    scanf("%d",&c);


if (a<b)
    if (b<c)
        Printf("l ordine e Abc");
    Else If (a<c)
        Printf("ordine acb");
    Else
Printf("ordine cab");
Else
If (a<c)
Printf("bac");
Else
If (b<c)
Printf("bca");
Else
Printf("cba");

    //stampo in ordine crescente
    if (a>b)
        if (b>c)
            printf("%d - %d - %d\n",a,b,c);
        else
            printf("%d - %d - %d\n",a,b,c);
    else if (a>c && c>b)
        printf("%d - %d - %d\n",a,c,b);
    else if (b>a && a>c)
        printf("%d - %d - %d\n",b,a,c);
    else if (b>c && c>a)
        printf("%d - %d - %d\n",b,c,a);
    else if (c>a && a>b)
        printf("%d - %d - %d\n",c,a,b);
    else
        printf("%d - %d - %d\n",c,b,a);

    //stampo in ordine decrescente
    if (a>b && b>c)
        printf("%d - %d - %d\n",a,b,c);
    else if (a>c && c>b)
        printf("%d - %d - %d\n",a,c,b);
    else if (b>a && a>c)
        printf("%d - %d - %d\n",b,a,c);
    else if (b>c && c>a)
        printf("%d - %d - %d\n",b,c,a);
    else if (c>a && a>b)
        printf("%d - %d - %d\n",c,a,b);
    else
        printf("%d - %d - %d\n",c,b,a);

    return 0;
}
