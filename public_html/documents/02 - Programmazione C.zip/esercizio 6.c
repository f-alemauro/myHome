/*Scrivere un programma che, dati due numeri interi inseriti da tastiera,
calcoli la differenza tra il maggiore ed il minore stampando a video il risultato;
successivamente stabilire se il risultato ottenuto è un numero pari o dispari
e stampare la risposta a video
*/

#include <stdio.h>

int main()
{
    int a,b;
    int difference;
    int resto;

    printf("Inserisci il primo numero: ");
    scanf("%d",&a);
    printf("Inserisci il secondo numero: ");
    scanf("%d",&b);

    if(a>b)
    {
        difference = a-b;
    }
    else
    {
        difference = b-a;
    }

    printf("La differenza tra il maggiore ed il minore è %d\n",difference);

    resto = difference%2;

    if (resto == 0)
    {
        printf("La differenza é pari!\n");
    }
    else
    {
        printf("La differenza é dispari!\n");
    }

    return 0;

}
