#include <stdio.h>
#define YEAR 2014

int main()
{
    printf("Hello World! It's %d! \n", YEAR);
    return 0;
}
