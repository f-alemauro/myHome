/*Scrivere un programma che legga tre numeri interi e ne esegua prima l’addizione
e poi la differenza, stampando a video le singole operazioni
numeriche con il risultato
*/

#include <stdio.h>

int main()
{
    int a,b;
    int sum, difference;

    printf("Inserisci il primo numero: ");
    scanf("%d",&a);
    printf("Inserisci il secondo numero: ");
    scanf("%d",&b);

    sum = a+b;
    difference = a - b;

    printf("La somma tra %d e %d è %d\n",a,b,sum);
    printf("La differenza tra %d e %d è %d\n",a,b,difference);

    return 0;

}
