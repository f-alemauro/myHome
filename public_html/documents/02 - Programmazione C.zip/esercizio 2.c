/*Scrivere un programma che legga quattro variabili intere (a, b, c, d)
e le stampi a video su quattro righe differenti.
*/

#include <stdio.h>

int main()
{
    int a; //variabile a di tipo int, intero
    int b;
    int c;
    int d;

    printf("Inserisci il primo numero: ");
    scanf("%d",&a);
    printf("Inserisci il secondo numero: ");
    scanf("%d",&b);
    printf("Inserisci il terzo numero: ");
    scanf("%d",&c);
    printf("Inserisci il quarto numero: ");
    scanf("%d",&d);

    printf("Il primo numero inserito è %d;\n",a);
    printf("Il secondo numero inserito è %d;\n",b);
    printf("Il terzo numero inserito è %d;\n",c);
    printf("Il quarto numero inserito è %d;\n",d);

    return 0;
}
