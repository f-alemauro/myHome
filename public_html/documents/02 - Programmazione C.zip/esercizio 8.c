/*Scrivere un programma che legga tre numeri interi inseriti da tastiera
e dica se l’addizione dei tre è un numero pari o dispari.
*/

#include <stdio.h>

int main()
{
    int a,b,c,resto;
    printf("Inserisci i tre numeri: ");
    scanf("%d %d %d",&a,&b,&c);

    resto = (a+b+c)%2;
    if (resto == 0)
        printf("La somma tra %d, %d e %d è pari\n",a,b,c);
    else
        printf("La somma tra %d, %d e %d è dispari\n",a,b,c);

    return 0;
}
