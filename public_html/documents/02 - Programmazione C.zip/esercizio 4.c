/*Scrivere un programma che, dati due numeri interi inseriti da tastiera
e corrispondenti rispettivamente a base ed altezza di un rettangolo,
ne calcoli area e perimetro; stampare a video i risultati
*/

#include <stdio.h>

int main()
{
    int base, height,area, perimeter;

    printf("Inserisci la base del rettangolo in cm: ");
    scanf("%d",&base);

    printf("Inserisci l'altezza del rettangolo in cm: ");
    scanf("%d",&height);

    perimeter = base*2 + height*2;
    area = base*height;

    printf("Il perimetro del rettangolo è %d cm\nL'area del rettangolo è %d cm\n",perimeter,area);

    return 0;


}
