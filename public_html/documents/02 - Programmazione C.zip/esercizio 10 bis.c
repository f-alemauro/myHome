/* stampare a video tutti i numeri pari minori di un numero N
inserito dall'utente da tastiera
*/

#include <stdio.h>

int main()
{
    int max, odd = 0;
    printf("Inserici il massimo: ");
    scanf("%d",&max);

    while ( odd != max)
    {
        printf("%d\n", odd);
        odd += 2;
    }
    return 0;
}
