/*
Si definisca un tipo strutturato SquadraBasket, che rappresenti i dati relativi a una squadra di
basket. Una squadra di basket è rappresentata dalle seguenti informazioni:
    - Nome della squadra: una stringa lunga al massimo 30 caratteri.
    - Città della squadra: una stringa lunga al massimo 30 caratteri.
    - Numero di giocatori che fanno parte della squadra: un intero, minore o uguale a 20.
    - L’insieme di Giocatori che compongono la squadra.
Un giocatore è un dato strutturato costituito da:
    • Nome del giocatore: una stringa lunga al massimo 30 caratteri.
    • Numero di partite giocate dal giocatore nella stagione corrente: un intero.
    • Numero di punti realizzati dal giocatore nella stagione corrente: un intero.

Scrivere un programma per la gestione di un campionato; si dichiari una variabile campionato,
come vettore di 16 squadre; dichiarare poi un vettore di squadre contenente le squadre del
campionato che hanno almeno 3 giocatori che hanno realizzato in media più di 10 punti a partita.

pseudocodice
leggendo il testo si può intuire che ci servirà un array di squadre. Una squadra è composta da
più campi (nome, città, ...): dobbiamo quindi creare un tipo di dato nuovo. Usiamo una struct.
Il "problema" è che ogni squadra vuole la lista dei giocatori; un giocatore a sua volta è
composto da diversi campi (nome,...) e dobbiamo quindi costruire anche per lui una struct.
Abbiamo due struct "annidate".

ATTENZIONE: è importante l'ordine di definizione delle struct! va quindi prima dichiarata la
struct per il giocatore e poi quella per la squadra; questo perchè quest'ultima utilizza al
suo interno la prima (che deve essere quindi già definita!)


per la ricerca delle squadre con almeno 3 giocate con media punti > 10 ci servono due cicli for
annidati; il più esterno
*/

#include <stdio.h>

#define MAXLEN 10

typedef struct
{
    char nome[30];
    int numeroPartire;
    int numeroPunt;

} giocatore;

typedef struct
{
   char nome[30];
   char citta[30];
   int numGiocatori;
   giocatore listaGiocatori[20];
} squadraBasket;

int main(){
    squadraBasket campionato[16], best[16];
    int k=0,i=0,j=0,numeroSquadre,counter=0;
    char risp;

    //segmento di codice per la popolazione del campionato!
    do
    {
        printf("\n\nInserimento nuova squadra: [%d]\n",i+1);
        printf("Inserisci il nome: ");
        scanf("%s", campionato[i].nome);
        printf("Inserisci città: ");
        scanf("%s", campionato[i].citta);
        printf("Numero giocatori: ");
        scanf("%d", &campionato[i].numGiocatori);
        getchar();
        j=0;
        printf("Vuoi inserire i giocatori? [y/n]");
        scanf("%c",&risp);
        while(risp!='n' && j < campionato[i].numGiocatori)
        {
                printf("Nome %d giocatore: ",j+1);
                scanf("%s",campionato[i].listaGiocatori[j].nome);
                printf("Numero partite %d giocatore: ",j+1);
                scanf("%d",&campionato[i].listaGiocatori[j].numeroPartire);
                printf("Punti %d giocatore: ",j+1);
                scanf("%d",&campionato[i].listaGiocatori[j].numeroPunt);
                getchar();
                j++;
                if(j < campionato[i].numGiocatori)
                {
                    printf("Vuoi inserire un altro giocatore? [y/n]");
                    scanf("%c",&risp);
                    getchar();
                }
                else
                    printf("Lista giocatori completa!\n");
        }

        i++;
        if(i < 16)
        {
            printf("Vuoi inserire un'altra squadra? [y/n]");
            scanf("%c",&risp);
        }
        else
            printf("Campionato al completo!\n");

    }while(risp!='n' && i < 16);

    numeroSquadre = i-1;

    //ricerca delle squadre con almeno tre giocatori che hanno realizzato mediamente più di
    //10 punti.
    for(i=0;i<numeroSquadre;i++)
    {
        counter = 0;
        for(j=0;j<campionato[i].numGiocatori;j++)
        {
            float mean = campionato[i].listaGiocatori[j].numeroPunt/campionato[i].listaGiocatori[j].numeroPartire;
            if (mean >= 10)
                counter++;

        }
        if (counter >= 3)
        {
            best[k] = campionato[i];
            k++;
        }
    }

    printf("\n\nLista delle migliori squadre: \n");
    for (i=0;i<k;i++)
    {
        printf("%s\n",best[i].nome);
    }

    return 0;
}
