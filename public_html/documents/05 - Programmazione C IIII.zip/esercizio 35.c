/*
Dati due array A e B di lunghezza massina N,
chiedere all'utente quanti numeri vuole inserire, leggere da tastiera A e B
e costruire quindi un array C (di dimensione massima 2N) che contenga
nelle posizioni di indice pari gli elementi di A e nelle posizioni
di indice dispari gli elementi di B.
*/

#include <stdio.h>

#define MAX 30

int main(){
    int i,j=0,n,a[MAX],b[MAX],c[2*MAX], d[2*MAX];

    do{
        printf("Inserisci il numero di elementi: ");
        scanf("%d",&n);
    }while(n < 0 || n>MAX);

    for(i=0;i<n;i++)
    {
        printf("A[%d]:",i);
        scanf("%d",&a[i]);
    }

    for(i=0;i<n;i++)
    {
        printf("B[%d]:",i);
        scanf("%d",&b[i]);
    }

    for(i=0;i<n;i++)
    {
        c[j++]= a[i];
        c[j++]= b[i];
    }
/*
    j=0;
    for(i=0;i<n;i++)
    {
        d[++j]= a[i];
        d[++j]= b[i];
    }
*/
    printf("C: ");

    for(i=0;i<2*n;i++)
    {
        printf("[%d]\t", c[i]);
    }
/*
    printf("\n\nD: ");

    for(i=0;i<2*n;i++)
    {
        printf("[%d]\t", d[i]);
    }
*/
    return 0;
}
