/*
Scrivere un programma che legga da tastiera un array di dimensione massima MAXLEN
contenente numeri interi negativi (zero per terminare l'inserimento); il programma deve copiare
l'array in un secondo array in ordine inverso e calcolare la media mean dei valori dispari
inseriti in posizioni multiple di due dell’array

*/

#include <stdio.h>

#define MAXLEN 20

int main(){

    int a[MAXLEN],b[MAXLEN],i=0,j,num,len,mean,counter=0;
    float sum=0;

    do{
        printf("Inserisci l'elemento [%d] ",i+1);
        scanf("%d",&num);
        if(num<0)
        {
            a[i]=num;
            i++;
        }
    }while(num != 0 || i > MAXLEN);
    len = i;

    printf("Array inserito: ");
    for(j=0;j<len;j++)
        printf("%d ",a[j]);

    j=0;
    for(i=len-1;i>=0;i--)
    {
        b[j]=a[i];
        j++;
    }


    printf("\nNuovo array: ");
    for(j=0;j<len;j++)
        printf("%d ",b[j]);

    for(j=0;j<len;j+=2)
        if (b[j]%2!=0)
        {
            sum+=b[j];
            counter++;
        }

    sum/=counter;
    printf("La media è %f",sum);
    return 0;
}
