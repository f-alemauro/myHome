/*
Scrivere un programma in linguaggio C che acquisisca da tastiera due valori interi
"row" e "col" (i due valori devono essere pari, maggiori di 0 e
minori di MAX =100). Acquisisca quindi da tastiera una matrice m di interi di dimensioni
massime MAX x MAX, organizzandoli su un numero di righe uguale a row e un numero di colonne uguale
a col. Stamparla a video ed estrarre quindi tutte le sottomatrici 2x2 e calcolarne il determinante


*/

#include <stdio.h>

#define MAX 100

int main(){

    int m[MAX][MAX], row, col,i,j,det;

    do{
        printf("Inserisci il numero di righe: ");
        scanf("%d",&row);
    }while(row < 0 || row>MAX || (row%2!=0));

    do{
        printf("Inserisci il numero di colonne: ");
        scanf("%d",&col);
    }while(col < 0 || col>MAX || col%2!=0);

    for(i = 0; i < row; i++)
        for(j = 0; j < col; j++){
            printf("Inserire l'elemento [%d, %d]: ", i, j);
            scanf("%d", &m[i][j]);
        }

    for(i = 0; i < row; i++){
        for(j = 0; j < col; j++)
            printf("%d\t",m[i][j]);
        printf("\n");
        }
    printf("\n Elenco delle sottomatrici 2x2")
   for(i = 0; i < row; i = i + 2)
        for(j = 0; j < col; j = j + 2)
        {
            det = (m[i][j] * m[i+1][j+1] - m[i+1][j] * m[i][j+1]);
            printf("%d\t%d\n%d\t%d",m[i][j],m[i][j+1],m[i+1][j],m[i+1][j+1]);
            printf("\n Il determinante della sottomatrice è %d\n",det);
        }


    return 0;
}
