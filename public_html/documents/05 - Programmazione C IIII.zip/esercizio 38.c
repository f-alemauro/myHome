/*
    Scrivere un programma che richieda all'utente di inserire i dati di studenti,
    al massimo N=10.
    Ogni studente è rappresentato da matricola, nome e cognome. Gli studenti devono
    essere inseriti in un vettore di struct, che deve essere mantenuto ordinato
    dopo ogni inserimento.

pseudocodice:
è necessario definire un array di studenti di lunghezza pari a N=10;
Dato che ogni studente è caratterizzato da matricola, nome e cognome, dobbiamo definire
un nuovo tipo di dato con una struct. La struct può essere poi utilizzata come una normale
variabile, che ha però dei "sottocampi".

typedef struct
{
   tipo membro_1;
   tipo membro_2;
   ...
   tipo membro_n;
} nomeTipo;

Esempio:

typedef struct
{
   char  title[50];
   char  author[50];
   char  subject[100];
   int   book_id;
} book;

Definita così si può accedere ai campi con l'operatore .
book libro;
libro.title = "titolo";
libro.book_id = 12;
...
*/

#include <stdio.h>

#define MAXLEN 10

typedef struct
{
   int matricola;
   char  nome[20];
   char  cognome[20];
} studente;

int main(){
    studente registro[MAXLEN],temp;
    char risp ='y';
    int len=0,i,j;
    do{
        //Richiedo i dati per il nuovo studente
        printf("Inserisci la matricola dello studente: ");
        scanf("%d",&registro[len].matricola);
        printf("Inserisci il nome dello studente: ");
        scanf("%s",registro[len].nome);
        getchar();
        printf("Inserisci il cognome dello studente: ");
        scanf("%s",registro[len].cognome);
        getchar();
        len++;


        //Riordino l'array
        for(i=0;i<len-1;i++)
            for(j=0;j<len-i-1;j++)
                if(registro[j].matricola>registro[j+1].matricola)
                {
                    temp=registro[j];
                    registro[j] = registro[j+1];
                    registro[j+1] = temp;
                }

        //stampo il registro ordinato
        for(i=0;i<len;i++)
            printf("%d. %d - %s %s\n",i,registro[i].matricola,registro[i].nome,registro[i].cognome);

        printf("Vuoi inserire un nuovo studente? ");
        scanf("%c",&risp);
        getchar();
    }while(risp!='n');

    return 0;
}
