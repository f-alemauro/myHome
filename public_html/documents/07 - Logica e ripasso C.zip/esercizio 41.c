/*Scrivere un programma che legga una array da tastiera e ne elimini i duplicati.
pseudocodice:

Dopo aver letto l'array da tastiera, deve elimare i duplicati.
Per ogni elemento, verifico se tra gli elementi successivi ce ne sono alcuni uguali.
In caso, per eliminarlo, devo "spostare indietro" di 1 tutti gli elementi successivi
e diminuire di 1 la lunghezza dell'array.
*/

#include<stdio.h>

int main() {
   int arr[20], i, j, k, size;

   printf("\nInserisci la dimensione dell'array : ");
   scanf("%d", &size);

   printf("\nInserisci l'array: ");
   for (i = 0; i < size; i++)
      scanf("%d", &arr[i]);


   for (i = 0; i < size; i++) {
      for (j = i + 1; j < size;) {
         if (arr[j] == arr[i]) {
            for (k = j; k < size; k++) {
               arr[k] = arr[k + 1];
            }
            size--;
         } else
            j++;
      }
   }

    printf("\nArray senza duplicati: ");
   for (i = 0; i < size; i++) {
      printf("%d ", arr[i]);
   }

   return (0);
}
