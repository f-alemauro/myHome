#include <stdio.h>
#define N 10
main()
{
	int r, c, mat[N][N];
	mat[0][0] = 1;
	for ( c=1 ; c<N ; c++ )
		mat[0][c] = 0;
	for ( r=1 ; r<N ; r++ )
	{
		mat[r][0] =1;
		for ( c=1 ; c<N ; c++ )
			mat[r][c] = mat[r-1][c-1] + mat[r-1][c];
	}
	for ( r=0 ; r<N ; r++ )
	{
		for ( c=0 ; c<=r ; c++ )
			printf("%6d", mat[r][c]);
		printf("\n");
	}
/*
	for ( r=0 ; r<N ; r++ )
    {
        // metto gli spazi bianchi all'inizio della riga r-ma
        for ( c=1 ; c<(N-r)*3 ; c++ )
            printf(" ");
        // scrivo i numeri della riga r-ma
        for ( c=0 ; c<=r ; c++ )
            printf("%6d", mat[r][c]);
        // fine della riga r-ma
        printf("\n");
    }
    */
	return 0;
}
