/*

Scrivere un programma che legga un numero naturale da tastiera e lo converta in binario
*/
#include<stdio.h>


int main()
{
    int decimalNumber,remainder,quotient;
    int binaryNumber[32],i=0,j;

    printf("Inserisci un numero decimale naturale: ");
    scanf("%d",&decimalNumber);

    quotient = decimalNumber;
    while(quotient!=0){
         binaryNumber[i++]= quotient % 2;
         quotient = quotient / 2;
    }

    printf("Il numero %d convertito in binario è: ",decimalNumber);

    for(j = i-1 ;j>= 0;j--)
         printf("%d",binaryNumber[j]);
    return 0;

}
