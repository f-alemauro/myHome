#include <stdio.h>

int main()
{
    int a1,a2,a3;
    char c1,c2,str[30];
    printf("Inserisci un numero:");
    scanf("%d",&a1);
    printf("Inserisci un numero:");
    scanf("%d",&a2);
    fflush(stdin);
    printf("Inserisci un carattere:");
    scanf("%c",&c1);
    printf("Stringa:");

    scanf("%s",str);
    fflush(stdin);
    printf("Inserisci un carattere:");
    scanf("%c",&c2);
    printf("Inserisci un numero:");
    scanf("%d",&a3);


    printf("%d - %d - %c - %c - %d",a1,a2,c1,c2,a3);
    return 0;
}

