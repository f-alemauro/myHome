/*
Sia M una matrice di dimensione NxN (N costante simbolica pari a 3) di numeri interi
appartenenti all’intervallo[0,9].
Si scriva un programma in grado di individuare il valore intero num che compare più
frequentemente nella matrice M e di visualizzare a schermo il contenuto della matric M,
 mostrando però un trattino (“-­‐“) al posto dei valori interi diversi da num.
*/

#include <stdio.h>

#define RANGE 10
#define N 3

int main()
{
    int M[N][N] = {{1,2,1},{12,2,1},{11,2,1}};
    int freq[RANGE];
    int i, j, k;
    int max, valmax;
    for(i= 0; i<RANGE; i++)
        freq[i]=0;
    for(i = 0; i < N; i++)
        for(j = 0; j < N; j++)
            freq[M[i][j]]++;
    max = 0;
    for(k = 0; k < RANGE; k++)
        if(freq[k] > max)
        {
            max = freq[k];
            valmax = k;
        }
    printf("\nValore %d con frequenza massima %d\n\n",valmax,max);
    for(i = 0; i < N; i++){
        for(j = 0; j < N; j++) {
            if(M[i][j] == valmax)
                printf("%d\t",M[i][j]);
            else
                printf("_\t");

        }
        printf("\n");
    }
    return 0;
}
