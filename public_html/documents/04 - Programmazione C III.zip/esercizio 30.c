/*
Scrivere un programma che definisca una matrice quadrata di dimensione N
e stampi a video se la matrice è simmetrica o no.
(Prima pensate all'algoritmo, poi pensate se può essere ottimizzato in qualche modo)

Pseudocodice: Una matrice tale che ai,j=aj,i è una matrice simmetrica

mat[ROW][COL]
i,j = 0
sim = 1

finche (i è minore del numero di righe)
    finchè (j è minore del numero di colonne)
        se mat[i,j] è diverso da mat[j,i] (notare gli indici invertiti)
            sim = 0
se sim è uguale a 0
    stampa "Matrice non simmetrica"
altrimenti
    stampa "Matrice simmetrica"
*/

#include <stdio.h>
#define ROW 3
#define COL 3

int main()
{
    int matrix[ROW][COL] = {{1,2,3},{4,5,6},{7,8,9}};
    int i,j,sim = 1;//Nota bene: sim è inizializzato ad 1;

    while(i<ROW)
    {
        j = 0;
        while(j<COL)
        {
            if (matrix[i][j] != matrix[j][i])//se scopro che la matrice non è simmetrica
                                             //aggiorno sim a 0; sim è la nostra "sentinella"
                sim = 0;
            ++j;
        }
    ++i;
    }

    if (sim)
        printf("Matrice simmetrica");
    else
        printf("Matrice non simmetrica");

    return 0;
}
