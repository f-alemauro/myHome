/*
Creare un registro di cognomi.
L'utente da tastiera può inserire un nuovo cognome (la lista non deve contenere duplicati),
leggere la lista di tutti i cognomi inseriti e verificare se un cognome esiste,
restituendone a video l'indice.

Pseudocodice:
abbiamo un ciclo do-while esterno che controlla la scelta dell'utente. Cicla fino a quando
l'utente non inserisce il carattere q.

All'interno abbiamo uno switch sul carattere appena immesso dall'utente; le opzioni sono
.c (cerca)
.v (visualizza)
.i (inserisci)
.q (quit)
default (comando non riconosciuto)

CERCA:
    se lista non è vuota
        index = -1
        leggi cognome da tastiera;
        finchè i è minore di numElem
            se reg[i] è uguale a cognome
                index = i
        se index è minore di 0
            scrivi "Non presente"
        altrimenti
            scrivi "Trovato, indice index"
    altrimenti
        scrivi "lista vuota"
INSERISCI:
    se lista non è piena (--> numElem < MAXLEN)
        leggi cognome da tastiera
            se lista non contiene cognome ->vedi funzione cerca
                strcpy reg[numElem],cognome
            altrimenti
                scrivi "Elemento già presente"
    altrimenti
        scrivi "lista piena"

VISUALIZZA:
    i = 0
    se lista non è vuota (--> numElem > 0)
        finchè (i è minore di numElem)
            scrivi reg[i]
    altrimenti
        scrivi "Lista vuota"
 */

#include <stdio.h>
#include <string.h>

#define MAXSURNAME 100
#define MAXLENGHT 20


int main()
{
    char reg[MAXSURNAME][MAXLENGHT];
    char surname[MAXLENGHT];
    int numElem = 0,index,i;
    char cmd;

    do
    {
        printf("Scegliere l'operazione da eseguire:[i][c][v][q]");
        scanf("%c", &cmd);
        getchar();
        switch(cmd)
        {
        case('c'):
            if (numElem != 0)
            {
                printf("\nInserire il cognome da cercare: ");
                scanf("%s", surname);
                getchar();
                index = -1;
                for (i=0; i<numElem; i++)
                    if (strcmp(reg[i], surname)==0)
                        index = i;
                if(index>=0)
                    printf("Cognome presente, indice %d",index);
                else
                    printf("Cognome non presente");
            }
            else
            {
                printf("\nRegistro vuoto!");

            }
            printf("\n");
            break;
        case('i'):
            if (numElem < MAXSURNAME)
            {
                printf("\nInserire il cognome da inserire: ");
                scanf("%s", surname);
                getchar();

                index = -1;
                for (i=0; i<numElem; i++)
                    if (strcmp(reg[i], surname)==0)
                        index = i;
                if(index<0)
                {
                    strcpy(reg[numElem],surname);
                    numElem++;
                    printf("\nCognome inserito corretamente");
                }
                else
                    printf("\nCognome già presente");
            }
            else
            {
                printf("\nRegistro pieno!");

            }
            printf("\n");
            break;
        case('v'):
            printf("\n:::ELENCO:::");
            for(i=0;i<numElem;i++)
                printf("\n%d. %s",i,reg[i]);
            printf("\n");
            break;
        default:
            printf("\nComando non valido!\n");
        }
    }while (cmd!='q');

    return 0;
}
