/*Scrivere un programma che legga una sequenza di numeri interi (-1 per terminare)
e la stampa in ordine invertito.
La lunghezza massima della sequenza deve essere minore od uguale a 50.
(attenzione: cosa succede se l'utente inserisce 51 numeri?)

maxlen = 50
indice = 0
numero = 0
array[maxlen]

finchè(numero diverso da -1 e indice < maxlen) (perchè??)
    leggi numero da tastiera
    se (numero diverso da -1)
        array[indice] = numero;
        indice = indice +1

se (indice = maxlen)
    scrivi "raggiunto limite"

finchè (indice > 0)
    stampa array[indice]
    indice = indice - 1

fine
*/



#include <stdio.h>
#define MAXLEN 10

int main()
{

   int a[MAXLEN], i=0, num;

   do{
        printf("Inserire un intero:\n");
        scanf ("%d", &num);

        if(num != -1)
        {
            a[i] = num;
            i++;
        }
   }while(num != -1 && i < MAXLEN);

   if (i == MAXLEN)
        printf("Hai raggiunto il limite!\n");

   while ( i > 0 ) {
     --i;
     printf("%d\n", a[i]);
   }
   return 0;
}
