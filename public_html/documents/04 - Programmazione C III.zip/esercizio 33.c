/*
 Scrivere un programma che verifichi se due stringhe inserite dall'utente da tastiera
 sono uguali.
 */

#include <stdio.h>
#define LEN 20


int main()
{
    char word1[LEN];
    char word2[LEN];
    int i,eq = 1;
    printf("Scrivi la prima parola: ");
    scanf("%s",word1);

    printf("Scrivi la seconda parola: ");
    scanf("%s",word2);


    for(i=0;i<LEN && word1[i]!='\0' && word2[i]!='\0';i++)
    {
        if (word1[i]!= word2[i])
            eq =0;
    }

    /* versione ottimizzata:
    for(i=0;i<LEN && word1[i]!='\0' && word2[i]!='\0' && eq!=0;i++) //esco dal ciclo for non
                                                    //appena eq viene aggiornato perchè ho
                                                    //trovato caratteri differenti
    {
        if (word1[i]!= word2[i])
            eq =0;
    }
    */
    if(eq)
        printf("Le due parole inserite sono identiche");
    else
        printf("Le due parole inserite non sono identiche");
    return 0;

}
