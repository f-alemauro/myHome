/*
 Scrivere un programma che chieda all'utente di inserire una parola e
 la ristampi a video con tutti i caratteri mauiscoli.
 */

#include <stdio.h>
#define LEN 20


int main()
{
    char word[LEN];
    int i;
    printf("Scrivi una parola: ");
    scanf("%s",word); //NOTA BENE: solo per le stringhe la & non va messa!

    printf("Hai inserito la parola %s",word);

    printf("\n\nLa parola %s in maiuscolo è: ",word);
    for(i=0;i<LEN && word[i]!='\0';i++)
    {

        printf("%c",word[i]-32); //ricordatevi sempre la conversione data dalla tabella ASCII!
    }
    /*OK, ma cosa succede se l'utente inserisce caratteri maiuscoli?
    for(i=0;i<LEN && word[i]!='\0';i++)
    {
        if(word[i]>96 && word[i]<123)
            printf("%c",word[i]-32);
        else
            printf("%c",word[i]);
    }
    CONTROLLATE SEMPRE GLI INPUT DA TASTIERA
    */

    return 0;
}
