/*Scrivere un programma che definisca una sequenza di numeri di
lunghezza massima MAXLEN definita a priori e ne calcoli il massimo,
il minimo e il valore medio.

PSEUDOCODICE:
a = 1,4,2,6,10
maxlen = 5
indice = 0
finchè (indice < maxlen)
    somma = somma+ a[i];
    se (a[i]> massimo)
        aggiorno massimo
    se (a[i]< minimo)
        aggiorno minimo
    indice = indice +1;

media = somma/maxlen
scrivi media, massimo,minimo.
*/



#include <stdio.h>
#define MAXLEN 5

int main()
{
    int max,min,i;
    int arr[MAXLEN] = {1,4,2,6,10};
    float mean,sum;
    max = arr[0];
    min = arr[0];
    sum = arr[0];
    for(i=1; i<MAXLEN;i++)
    {
        sum +=arr[i];
        if (arr[i]>max)
            max = arr[i];
        if (arr[i]<min)
            min = arr[i];
    }
    mean = sum/MAXLEN;

    printf("La media del vettore è %f\n",mean);
    printf("Il massimo del vettore è %d\n",max);
    printf("Il minimo del vettore è %d",min);
    return 0;
}
