/*
Scrivere un programma che definisca una stringa di lunghezza LEN
e la stampi a video prima normale e poi al contrario
(Ricordatevi che una stringa è un array di caratteri!)*/

#include <stdio.h>
#define LEN 20


int main()
{
    //Diversi modi di definire una stringa, notate la differenza tra apice singolo ', che
    //identifica un carattere, e apice doppio " che racchiude una string.

    char c[LEN] = {'H','e','l','l','o','\0'};
    char c1[LEN] = "Hello world";
    int i;


    //diversi modi di stampare una stringa
    printf("Prima stringa: %s\n",c);
    printf("Seconda stringa: %s\n",c1);

    for(i=0; i<LEN;i++)
    {
        printf("%c",c[i]);
    }

    printf("\n");
    for(i=0; i<LEN;i++)
    {
        printf("%c",c1[i]);
    }

    printf("\n");
    i = 0;
    while(c[i]!='\0')
    {
        printf("%c",c[i]);
        i++;
    }

    printf("\n");
    i = 0;
    while(c1[i]!='\0')
    {
        printf("%c",c1[i]);
        i++;
    }

    //stampiamo le due stringhe al contrario


    printf("\n");
    i = LEN-1;
    while(i>=0)
    {
        printf("%c",c[i]);
        i--;
    }

    //Il while qui sopra non è per niente ottimizzato.
    //Meglio prima calcolare la lunghezza della stringa.

    printf("\n");
    int length=0;
    while(c[length]!='\0')
    {
        length++;
    }


    while(length>=0)
    {
        printf("%c",c[length]);
        length--;
    }
    return 0;
}
