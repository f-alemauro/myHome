/* Scrivere un programma che definisca un sequenza di numeri interi (=array)
e la stampi a video, prima in ordine di inserimento, poi al contrario.
*/

#include <stdio.h>


int main()
{
    int i; //variabile contatore per i cicli for

    /*questi sono tre modi identici di dichiarare un array*/

    int seq[5] = {1,4,2,6,10};

    int seq1[] = {7,3,1,23};

    int seq2[4];
    seq2[0] = 1;
    seq2[1] = 10;
    seq2[2] = 90;
    seq2[3] = 4;

    printf("Array normali:\n\n");
    printf("seq: ");
    for (i = 0; i < 5; i++ )
    {
      printf("%d ", seq[i]);
    }

    printf("\nseq1: ");
    for (i = 0; i < 4; i++ )
    {
      printf("%d ", seq1[i]);
    }

    printf("\nseq2: ");
    for (i = 0; i < 4; i++ )
    {
      printf("%d ", seq2[i]);
    }

    printf("\n\n\nArray al contrario: \n\n");
    printf("seq: ");
    for (i = 4; i >= 0; i-- )
    {
      printf("%d ", seq[i]);
    }

    printf("\nseq1: ");
    for (i = 3; i >= 0; i-- )
    {
      printf("%d ", seq1[i]);
    }

    printf("\nseq2: ");
    for (i = 3; i >= 0; i-- )
    {
      printf("%d ", seq2[i]);
    }


    return 0;
}
