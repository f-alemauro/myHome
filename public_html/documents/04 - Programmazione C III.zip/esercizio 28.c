/*
Dato un array di caratteri non ordinato,
ordinarlo in ordine crescente e stamparlo a video.

Pseudocodice (bubble sort)
A partire dal primo elemento della lista, comparo ogni coppia di elementi adiacenti;
scambio la loro posizione se non sono già nell'ordine corretto;
ripeto questa scansione N-1 volte.

i,j=0
len = 5
c = f,e,d,z,k
//devo scansionare l'array len-1 volte (l'ultima iterazione non è necessaria perchè
//l'ultimo elemento è già stato considerato
finchè (i è minore di len-1)
    finchè (j è minore di len-i-1) //scansione tutto l'array, fino all'elemento
                                    //len-i-1 perchè gli ultimi i elementi sono già in ordine
            se c[j] è maggiore di c[j+1] //se non sono in ordine li scambio.
                scambio c[j] con c[j+1]

stampo array ordinato.
Fine


Questo è uno dei tanti algoritmi di ordinamento di array; è uno tra i più semplici;
ce ne sono di più complessi, ma molto più efficienti (veloci): bucket sort, heap sort,merge sort...
*/

#include <stdio.h>
#define LEN 5

int main()
{
    char c[LEN] = {'f','e','d','z','k'};
    char swap;
    int i,j;
    for (i=0;i<(LEN-1); i++)
    {
        for (j=0; j<(LEN-i-1); j++)
        {
            if (c[j] > c[j+1])
            {
                swap = c[j];
                c[j] = c[j+1];
                c[j+1] = swap;
            }
        }
    }
    printf("Array ordinato:\n");

    for (i=0 ; i<5 ;i++ )
        printf("%c\n", c[i]);
    return 0;
}
