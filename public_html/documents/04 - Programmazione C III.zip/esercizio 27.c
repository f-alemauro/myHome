/*Data una sequenza di caratteri, scrivere un programma che chieda
all'utente di inserire un carattere da tastiera e verifichi se è presente nella sequenza.
In caso positivo stampare a video l'indice della prima occorrenza, -1 altrimenti.

pseudocodice:

indice = -1
i = 0
arr[4] = a,b,c,d
char c


finche(i < 5)
    leggi da tastiera c
    se(arr[i] è uguale a c)
        indice = i
        fine
    i = i+1;

stampa a video indice.
fine
*/



#include <stdio.h>
#define MAXLEN 4

int main()
{
   char seq[MAXLEN] = {'a','b','c','d'};
   char c;
   int i,indice= -1;

   printf("inserisci un carattere: ");
   scanf("%c",&c);

   //Prima versione:
    for(i = 0;i<MAXLEN;i++)
    {
        printf("%d ",i);
        if (seq[i]==c)
            indice = i;
    }
    printf("\n");
    indice= -1;
    //seconda versione, ottimizzata, ma con break!
    for(i = 0;i<MAXLEN;i++)
    {
        printf("%d ",i);
        if (seq[i]==c){
            indice = i;
            break;
        }
    }

    printf("\n");

    indice= -1;
    //terza versione, meglio!
    for(i = 0;i<MAXLEN && indice==-1;i++)
    {
        printf("%d ",i);
        if (seq[i]==c)
            indice = i;

    }

    printf("\n");
    printf("Indice: %d",indice);
    return 0;
}
