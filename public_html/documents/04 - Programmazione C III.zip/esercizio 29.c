/*
Scrivere un programma che definisca una matrice quadrata di interi di dimensione N
e la stampi a video.
*/

#include <stdio.h>
#define ROW 3
#define COL 3

int main()
{
    int matrix[ROW][COL] = {{0,1,2},{3,4,5},{6,7,8}};
    int i,j;

    //Mi servono due cicli annidati; quello più esterno scorre le righe.
    //Fissata una riga, con il ciclo più interno stampo uno ad uno tutti gli
    //elementi di quella riga (scansiono le colonne)
    for(i=0;i<ROW;i++)
    {
        for(j=0;j<COL;j++)
            printf("%d\t",matrix[i][j]);
        printf("\n");
    }

    return 0;
}
