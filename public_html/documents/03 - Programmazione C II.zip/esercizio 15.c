/* Scrivere un programma che, dato un numero intero inserito da tastiera,
 stampi a video tutti i suoi divisori;
*/

#include <stdio.h>


int main()
{
    int num,i;
    printf("Inserisci un numero intero positivo: ");

    scanf("%d",&num);


    if(num>0)
    {
        printf("I divisori di %d sono: ",num);

        for(i=1;i<=num/2;i++)
            if(num%i==0)
                printf("%d - ",i);
    }
    else
        printf("Numero inserito non valido\n");
    return 0;
}
