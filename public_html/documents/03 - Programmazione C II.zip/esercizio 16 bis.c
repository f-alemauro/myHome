/*Scrivere un programma che stampi a video, dato un numero intero x in ingresso,
stampi tutti I numeri interi da x a 0;
*/

#include <stdio.h>


int main()
{
    int max,i;
    printf("Inserisci un numero intero positivo: ");

    scanf("%d",&max);

    if(max>0)
    {
        for(i=max;i>0;i--)
                printf("%d - ",i);

        printf("%d",i);
    }
    else
        printf("Numero inserito non valido\n");
    return 0;
}
