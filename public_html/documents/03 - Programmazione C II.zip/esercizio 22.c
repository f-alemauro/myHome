/* Scrivere un programma che, a seconda del voto inserito (A,B,C,D,E) da tastiera,
 stampi a video un commento
 (ad esempio, inserendo “A” da tastiera il programma potrebbe scrivere
  in output “Eccellente!”);
*/

#include <stdio.h>


int main()
{
    int option;
    float res, a,b;
    printf("Inserisci due numeri: ");

    scanf("%f %f",&a,&b);

    printf("---MENU----\n");
    printf("___________\n");
    printf("0 - Termina\n");
    printf("1 - Somma\n");
    printf("2 - Differenza\n");
    printf("3 - Maggiore\n");

    printf("Cosa vuoi fare? ");
    scanf("%d",&option);

    switch(option)
    {
        case(1):
            res = a+b;
            break;
        case(2):
            res = a-b;
            break;
        case(3):
            if(a>b)
                res = a;
            else
                res = b;
            break;
        case(0):
            printf("Fine del programma!\n");
            return 0;
            break;
        default:
            printf("Scelta non corretta!\n");
            return 0;
    }

    printf("Il risultato dell'operazione è %2.2f",res);
    return 0;
}
