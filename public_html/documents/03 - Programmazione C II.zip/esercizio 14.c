/* Scrivere un programma che legge da tastiera un carattere minuscolo
e ne stampa il codice ASCII;
il programma deve continuare sino a quanto l'utente inserisce un carattere non minuscolo.
*/

#include <stdio.h>
int main() {

    char c;
    printf("scrivi un car. minuscolo (ogni altro per finire)\n");
    scanf("%c", &c);
    while( c >= 'a'&& c <= 'z')
    {
        printf("valore ASCII per %c risulta %d\n", c, c);
        printf("scrivi un car. minuscolo (ogni altro per finire)\n");
        scanf("%c", &c);
        scanf("%c", &c);
    }
    return 0;
}
