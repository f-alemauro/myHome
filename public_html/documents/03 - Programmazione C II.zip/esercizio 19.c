/* Scrivere un programma che sommi tutti i numeri positivi inseriti
dall'utente da tastiera;
l'esecuzione termina quando l'utente inserisce 0;
i numeri negativi inseriti non devono essere sommati.
*/

#include <stdio.h>

int main()
{
    int num;
    int sum=0;
    do{

        printf("Inserisci un numero: ");
        scanf("%d",&num);
        if(num<0)
            continue;
        sum+=num;
    }while(num!=0);
    printf("La somma è %d",sum);
    return 0;
}
