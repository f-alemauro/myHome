/* Scrivere un programma che stampi a video la somma dei primi N
numeri naturali, dove N è un intero positivo inserito da tastiera;
*/

#include <stdio.h>


int main()
{
    int num,i,sum = 0;
    printf("Inserisci un numero intero positivo: ");

    scanf("%d",&num);

    if(num>0)
    {

        for(i=1;i<=num;i++)
            sum+=i;
        printf("La somma è %d ",sum);
    }

    else
        printf("Numero inserito non valido\n");
    return 0;
}
