/* Scrivere un programma che, a seconda del voto inserito (A,B,C,D,E) da tastiera,
 stampi a video un commento
 (ad esempio, inserendo “A” da tastiera il programma potrebbe scrivere
  in output “Eccellente!”);
*/

#include <stdio.h>


int main()
{
    char grade;
    printf("Inserisci il voto dello studente: ");

    scanf("%c",&grade);

    if (grade == 'a')
        printf("Eccellente!\n");
    else if (grade == 'b')
        printf("Ottimo!\n");
    else if (grade == 'c')
        printf("Insoma...!\n");
    else if (grade == 'd')
        printf("Lasciamo perdere!\n");
    else
        printf("Voto non corretto!\n");

    return 0;
}
