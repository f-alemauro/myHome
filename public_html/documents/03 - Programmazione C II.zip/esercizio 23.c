/* Chiedere all'utente di inserire un numero intero positivo da tastiera;
chiedere poi all'utente in quale base (ottale, decimale, esadecimale)
vuole convertirlo e stampare a video il numero convertito di conseguenza.
Aggiunta: continuare l'esecuzione del programma sino a quando l'utente inserisce
un numero negativo da tastiera
*/

#include <stdio.h>


int main()
{
    int num;
    char option;
    do{
        printf("Inserisci il numero intero positivo da convertire (negativo per terminare): ");
        scanf("%d",&num);
        getchar();
        printf("---MENU----\n");
        printf("___________\n");
        printf("o - base ottale\n");
        printf("d - base decimale\n");
        printf("e - base esadecimale\n");
        printf("Scegli la base: ");
        scanf("%c",&option);

        switch(option)
        {
            case('o'):
                printf("Numero %d convertito in base ottale: %o\n",num,num);
                break;
            case('d'):
                printf("Numero %d convertito in base decimale: %d\n",num,num);
                break;
        case('e'):
                printf("Numero %d convertito in base esadecimale: %e\n",num,num);
                break;
        default:
                printf("Scelta non corretta!\n");

        }
    }while(num>0);
    return 0;
}
