/* Scrivere un programma che, a seconda del voto inserito (A,B,C,D,E) da tastiera,
 stampi a video un commento
 (ad esempio, inserendo “A” da tastiera il programma potrebbe scrivere
  in output “Eccellente!”);
*/

#include <stdio.h>


int main()
{
    char grade;
    printf("Inserisci il voto dello studente: ");

    scanf("%c",&grade);
    switch(grade)
    {
        case('a'):
            printf("Eccellente!\n");
            break;
        case('b'):
            printf("Ottimo!\n");
            break;
        case('c'):
            printf("Insoma...!\n");
            break;
        case('d'):
            printf("Lasciamo perdere!\n");
            break;
        default:
            printf("Voto non corretto!\n");
    }

    return 0;
}
