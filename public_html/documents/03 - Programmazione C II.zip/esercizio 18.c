/*Scrivere un programma che chieda all’utente di inserire numeri interi
da tastiera e li ristampi immediatamente a video; il programma termina quando
l’utente inserisce uno zero (lo zero non deve essere stampato a video).
(ATTENZIONE: lo abbiamo appena visto con il while, qui lo facciamo con il DO-WHILE!)
*/

#include <stdio.h>

int main()
{
    int num;

    do{

        printf("Inserisci il prossimo numero: ");
        scanf("%d",&num);
        if(num!=0)
            printf("Hai inserito %d.\n",num);
    }while(num!=0);

    return 0;
}
