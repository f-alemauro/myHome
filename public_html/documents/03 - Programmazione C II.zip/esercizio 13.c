/*Scrivere un programma che stampi a video l'alfabeto “a-z”
(AIUTO: ricordatevi che in c il tipo char è equivalente al tipo intero,
con la conversione data dalla tabella ascii)
*/

#include <stdio.h>


int main()
{
    int i;
    for (i=97;i<123;i++)
        printf("%c\n",i);

    return 0;
}
